﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk;
using Microsoft.Xrm.Sdk;

namespace XIRRPlugin
{
    public class XIRRClass : IPlugin
    {
        void IPlugin.Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext) serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService = (ITracingService) serviceProvider.GetService(typeof(ITracingService));

            if (context != null)
            {
                Entity entity = null;

                if (context.InputParameters.Contains("Target"))
                {
                    tracingService.Trace("stage 1");
                    if (context.InputParameters["Target"] is Entity)
                    {
                        tracingService.Trace("stage 2");
                        entity = (Entity)context.InputParameters["Target"];
                        //var contact = entity.ToEntity<Transaction>();
                    }
                }

                if (entity != null)
                {
                    tracingService.Trace("stage 3");

                    if (entity.Attributes.ContainsKey("cr471_cashflow"))
                    {
                        tracingService.Trace("stage 4");
                        decimal cashflow = (decimal)entity["cr471_cashflow"];
                        entity["cr471_cashflow"] = 999;
                        tracingService.Trace("stage 5");
                    }

                    //if (entity.Attributes.ContainsKey("cr471_date"))
                    //{
                        tracingService.Trace("stage 6");
                        DateTime date = (DateTime)entity["cr471_date"];
                        tracingService.Trace("stage 7");
                    //}

                }
            }
        }
    }
}
